using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine;
using UnityEngine.EventSystems;

/*[System.Serializable]
public class EventVector3 : UnityEvent<Vector3> { }*/
public class MouseManager : SingleTon<MouseManager>
{
    
    public Texture2D point, doorway, attack, target, arrow;

    RaycastHit hitInfo;
    
    public event Action<Vector3> OnMouseClicked;

    public event Action<GameObject> OnStuffClicked;


    protected override void Awake()
    {
        base.Awake();
        DontDestroyOnLoad(this);
    }
    void Update()
    {
        CameraRayPoint();
        if (InteractWithUI()) return;
        MouseControl();
    }
    public int Testt()
    {
        return 1;
    }

    //�������������
    void CameraRayPoint()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);   
        //ͨ��out��hitinfo�����괫����
        if (Physics.Raycast(ray, out hitInfo))
        {
            switch(hitInfo.collider.gameObject.tag)
            {
                case "Ground":
                    Cursor.SetCursor(target, new Vector2(16, 16), CursorMode.Auto);
                    break;
                case "Enemy":
                    Cursor.SetCursor(attack, new Vector2(16, 16), CursorMode.Auto);
                    break;
                case "Door":
                    Cursor.SetCursor(doorway, new Vector2(16, 16), CursorMode.Auto);
                    break;
                case "Item":
                    Cursor.SetCursor(point, new Vector2(16, 16), CursorMode.Auto);
                    break;
                default:
                    Cursor.SetCursor(arrow, new Vector2(16, 16), CursorMode.Auto);
                    break;

            }
        }
    }

    //��������ȡĿ��ֵ����ֵ��Ӧ�ķ���
    void MouseControl()
    {
        if (Input.GetMouseButtonDown(0) && hitInfo.collider != null)
        {
            if (hitInfo.collider.gameObject.CompareTag("Ground"))
            {
                //If event does not null��then invoke,you need to register
                OnMouseClicked?.Invoke(hitInfo.point);              
            }
            if (hitInfo.collider.gameObject.CompareTag("Enemy"))
            {              
                OnStuffClicked?.Invoke(hitInfo.collider.gameObject);
            }
            if (hitInfo.collider.gameObject.CompareTag("Attackable"))
            {
                OnStuffClicked?.Invoke(hitInfo.collider.gameObject);           
            }
            if (hitInfo.collider.gameObject.CompareTag("Door"))
            {

                OnMouseClicked?.Invoke(hitInfo.point);

            }
            if (hitInfo.collider.gameObject.CompareTag("Item"))
            {

                OnMouseClicked?.Invoke(hitInfo.point);

            }
        }
    }
    bool InteractWithUI()
    {
        if(EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
        {
            return true;
        }
        return false;
    }
}

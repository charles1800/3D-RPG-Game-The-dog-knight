using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class QuestManager : SingleTon<QuestManager>
{
    [System.Serializable]
    public class QuestTask
    {
        public QuestData_SO questData;
        public bool IsStarted {
            get { return questData.isStarted; }
            set { questData.isStarted = value; } 
        }
        public bool IsCompleted
        {
            get { return questData.isCompleted; }
            set { questData.isCompleted = value; }
        }
        public bool IsFinished
        {
            get { return questData.isFinshed; }
            set { questData.isFinshed = value; }
        }
    } 
    public List<QuestTask> tasks = new List<QuestTask>();
    /// <summary>
    /// ʰȡ��Ʒ����NPC������ʱ����÷���
    /// </summary>
    /// <param name="requireName"></param>
    /// <param name="amount"></param>
    public void UpdateProgress(string requireName , int amount)
    {
        foreach(var task in tasks)
        {
            var matchTask = task.questData.requireList.Find(r => r.requireName == requireName);
            if(matchTask != null)
            {
                matchTask.currentAmount += amount;
            }
            task.questData.CheckQuestProgress();
        }
    }
    public bool HaveQuest(QuestData_SO data)
    {
        if(data != null)
            return tasks.Any(q => q.questData.questName == data.questName);
        else
            return false;      
    }
    /// <summary>
    /// �����List�����ҵ���Ŀ������������ͬ�������򷵻�һ��QuestTask����
    /// </summary>
    /// <param name="data"></param>
    /// <returns></returns>
    public QuestTask GetQusetTask(QuestData_SO data)
    {
        return tasks.Find(q => q.questData.questName == data.questName);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryManager : SingleTon<InventoryManager>
{
    public class DragData
    {
        public SlotHolder originalHolder;
        public RectTransform originalParent;
    }
    //TODO������ģ���������ݱ���
    [Header("Inventory Data")]
    public InventoryData_SO inventoryData;
    public InventoryData_SO actionData;
    public InventoryData_SO equipmentData;
    public InventoryData_SO inventoryDataTemple;
    public InventoryData_SO actionDataTemple;
    public InventoryData_SO equipmentDataTemple;
    /// <summary>
    /// �ֿ�����
    /// </summary>
    [Header("Container")]
    public ContainerUI inventoryUI;
    public ContainerUI actionUI;
    public ContainerUI equipmentUI;

    [Header("DragCanvas")]
    public Canvas dragCanvas;

    [Header("UI Panel")]
    public GameObject InventoryPanel;
    public GameObject StatsPanel;
    bool isOpen;

    [Header("Stats Text")]
    public Text healthText;
    public Text attackText;
    [Header("Tool Tips")]
    public ItemToolTip ToolInfo;


    /// <summary>
    /// ������קʱ�����λ���Լ�����
    /// </summary>
    public DragData currentDrag;
    void Start()
    {
        LoadData();
        inventoryUI.RefreshUI();
        actionUI.RefreshUI();
        equipmentUI.RefreshUI();   
    }
    protected override void Awake()
    {
        base.Awake();
        if(inventoryDataTemple != null)
        {
            inventoryData = Instantiate(inventoryDataTemple);
        }
        if (actionDataTemple != null)
        {
            actionData = Instantiate(actionDataTemple);
        }
        if (equipmentDataTemple != null)
        {
            equipmentData = Instantiate(equipmentDataTemple);
        }
    }
    /// <summary>
    /// ����ֿ�����
    /// </summary>
    public void SaveData()
    {
        SaveManager.Instance.Save(inventoryData, inventoryData.name);
        SaveManager.Instance.Save(actionData, actionData.name);
        SaveManager.Instance.Save(equipmentData, equipmentData.name);
    }
    public void LoadData()
    {
        SaveManager.Instance.Load(inventoryData, inventoryData.name);
        SaveManager.Instance.Load(actionData, actionData.name);
        SaveManager.Instance.Load(equipmentData, equipmentData.name);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.B))
        {
            isOpen = !isOpen;
            InventoryPanel.SetActive(isOpen);
            StatsPanel.SetActive(isOpen);
        }

        UpdateStatsText(
            GameManager.Instance.playerData.MaxHealth,
            GameManager.Instance.playerData.CurrentHealthy,
            GameManager.Instance.playerData.attackData.minDamage,
            GameManager.Instance.playerData.attackData.maxDamage
            );
    }
    public void UpdateStatsText(int health,int currentHealth,int min,int max)
    {
        healthText.text = currentHealth + " / " + health;
        attackText.text = min + " - " + max;
    }

    #region �����ק��Ʒ�Ƿ���Slot��Χ��
    /// <summary>
    /// �����ק��Ʒ�Ƿ���Slot��Χ��
    /// </summary>
    /// <param name="position"></param>
    /// <returns></returns>
    public bool CheckInventory(Vector3 position)
    {
        for(int i = 0; i < inventoryUI.slotHolders.Length; i++)
        {
            RectTransform rectTransform = inventoryUI.slotHolders[i].transform as RectTransform;
            if(RectTransformUtility.RectangleContainsScreenPoint(rectTransform, position))           
                return true;         
        }
        return false;
    }
    public bool CheckActionUI(Vector3 position)
    {
        for (int i = 0; i < actionUI.slotHolders.Length; i++)
        {
            RectTransform rectTransform = actionUI.slotHolders[i].transform as RectTransform;
            if (RectTransformUtility.RectangleContainsScreenPoint(rectTransform, position))
            {
                return true;
            }
        }
        return false;
    }
    public bool CheckEquipmentUI(Vector3 position)
    {
        for (int i = 0; i < equipmentUI.slotHolders.Length; i++)
        {
            RectTransform rectTransform = equipmentUI.slotHolders[i].transform as RectTransform;
            if (RectTransformUtility.RectangleContainsScreenPoint(rectTransform, position))
            {
                return true;
            }
        }
        return false;
    }
    #endregion

    #region ���������Ʒ
    /// <summary>
    /// ��������ʱ��鱳���Ƿ�����ص�������Ʒ,�������������������
    /// </summary>
    /// <param name="requireItemName"></param>
    /// <param name="amount"></param>
    public void CheckRequireItemInBag(string requireItemName)
    {
        foreach(var item in inventoryData.items)
        {
            if (item.itemData != null) 
            { 
                if(item.itemData.itemName == requireItemName)
                {QuestManager.Instance.UpdateProgress(item.itemData.itemName, item.itemAmount);}
            }
        }
        foreach (var item in actionData.items)
        {
            if (item.itemData != null)
            {
                if (item.itemData.itemName == requireItemName)
                {
                    QuestManager.Instance.UpdateProgress(item.itemData.itemName, item.itemAmount);
                }
            }
        }
    }
    #endregion

    //��鱳���Լ��������Ʒ
    public InventoryItem QuestItemInBag(ItemData_SO questItem)
    {      
        return inventoryData.items.Find(item => item.itemData = questItem);
    }
    public InventoryItem QuestItemInAction(ItemData_SO questItem)
    {
        return actionData.items.Find(item => item.itemData = questItem);
    }
}

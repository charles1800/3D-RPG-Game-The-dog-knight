using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class GameManager : SingleTon<GameManager>
{
    public CharacterData playerData;
    private CinemachineFreeLook freeLook;
    List<IEndGameObserver> endGameObservers = new List<IEndGameObserver>();
    protected override void Awake()
    {
        base.Awake();
        DontDestroyOnLoad(this);
    }
    public void RegisterPlayer(CharacterData player)
    {
        playerData = player;
        freeLook = FindObjectOfType<CinemachineFreeLook>();
        if (freeLook != null)
        {      
            freeLook.Follow = playerData.transform.GetChild(2);
            freeLook.LookAt = playerData.transform.GetChild(2);
        }
    }
    public void AddObserver(IEndGameObserver observer)
    {
        endGameObservers.Add(observer);
    }
    public void RemoveObserver(IEndGameObserver observer)
    {
        endGameObservers.Remove(observer);
    }

    /// <summary>
    /// ���м���List�еĶ��󶼻�ִ��������Ĵ��룬�����˹㲥������
    /// </summary>
    public void NotifyObserver()
    {
        foreach(var observer in endGameObservers)
        {
            observer.EndNotify();
        }
    } 
    public Transform GetEntrance()
    {
        foreach(var item in FindObjectsOfType<TransitionDestination>())
        {
            if(item.destinationTag == TransitionDestination.DestinationTag.Birth)
            {
                return item.transform;
            }
        }
        return null;
    }
}

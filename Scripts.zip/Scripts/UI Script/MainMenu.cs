using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Playables;

public class MainMenu : MonoBehaviour
{
    Button newGame;
    Button continueGame;
    Button quitGame;

    PlayableDirector playableDirector;

    private void Awake()
    {
        newGame = transform.GetChild(1).GetComponent<Button>();
        continueGame = transform.GetChild(2).GetComponent<Button>();
        quitGame = transform.GetChild(3).GetComponent<Button>();

        newGame.onClick.AddListener(PlayTimeLine);
        continueGame.onClick.AddListener(ContinueGame);
        quitGame.onClick.AddListener(QuitGame);

        playableDirector = FindObjectOfType<PlayableDirector>();
        //��TimeLine������ɺ�ִ��NewGame
        playableDirector.stopped += NewGame;
    }
    void PlayTimeLine()
    {
        playableDirector.Play();
    }
    void NewGame(PlayableDirector obj)
    {
        PlayerPrefs.DeleteAll();
        SceneManager.Instance.TransitionToFirstLevel();
    }
    void ContinueGame()
    {

        SceneManager.Instance.TransitionToLoadGame();
    }

    void QuitGame()
    {
        Application.Quit();
        Debug.Log("�Ƴ���Ϸ");
    }
}

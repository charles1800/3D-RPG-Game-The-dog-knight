using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class HealthBar : MonoBehaviour
{
    public GameObject healthBarPrefab;
    public Transform barPoint;

    Image healthSlider;
    Transform UIbar;
    public Transform cam;
    CharacterData currentStats;

    private void Awake()
    {
        //TODO:������ʾ�����ʼѪ��
        currentStats = GetComponent<CharacterData>();
        currentStats.UpdateHealthBarWhenAttack += UpdateHealthBar;
        Debug.Log(currentStats);
    }
    void OnEnable()
    {
        cam = Camera.main.transform;

        foreach(Canvas canvas in FindObjectsOfType<Canvas>())
        {
            if(canvas.renderMode == RenderMode.WorldSpace)
            {
                UIbar = Instantiate(healthBarPrefab, canvas.transform).transform;
                healthSlider = UIbar.GetChild(0).GetComponent<Image>();
            }
        }
    }
     void UpdateHealthBar(int currentHealth, int maxHealth)
    {
        if (currentHealth <= 0)
        {
            Destroy(UIbar.gameObject);
        }
        else
        {
            UIbar.gameObject.SetActive(true);
            float sliderPercent = (float)currentHealth / maxHealth;
            healthSlider.fillAmount = sliderPercent;
        }
    }
    private void LateUpdate()
    {
        if (UIbar != null)
        {
            UIbar.position = barPoint.position;
            UIbar.forward = -cam.forward;
        }
    }

}

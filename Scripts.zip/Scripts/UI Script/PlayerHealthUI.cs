using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealthUI : MonoBehaviour
{
    Text levelText;
    Image healthSlider;
    Image expSlider;
    private void Awake()
    {
        levelText = transform.GetChild(2).GetComponent<Text>();
        healthSlider = transform.GetChild(0).GetChild(0).GetComponent<Image>();
        expSlider = transform.GetChild(1).GetChild(0).GetComponent<Image>();
    }
    private void Update()
    {
        UpdateExp();
        UpdateHealth();
        levelText.text ="Level :" + GameManager.Instance.playerData.characterData.currentLevel;
    }

    void UpdateHealth()
    {
        //ͨ��GameManager����������ű���ȡPlayer�����ݡ�
        float sliderPercent = (float)GameManager.Instance.playerData.CurrentHealthy / GameManager.Instance.playerData.MaxHealth;
        healthSlider.fillAmount = 1 - sliderPercent;
    }
    void UpdateExp()
    {
        if (GameManager.Instance.playerData == null) return;
        float sliderPercent = (float)GameManager.Instance.playerData.characterData.currentExp / GameManager.Instance.playerData.characterData.baseExp;
        expSlider.fillAmount = sliderPercent;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActionButton : MonoBehaviour
{
    public KeyCode actionKey;

    public SlotHolder currentSlotHolder;

    private void Awake()
    {
        currentSlotHolder  = GetComponent<SlotHolder>(); 
    }

    void Update()
    {
        if(Input.GetKeyUp(actionKey) && currentSlotHolder.itemUI.GetItemOfItemData())
        {
            currentSlotHolder.UseItem();
        }
    }
}

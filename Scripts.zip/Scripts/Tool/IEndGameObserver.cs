public interface IEndGameObserver
{
    /// <summary>
    /// Stop all behavior
    /// </summary>
    void EndNotify();

}

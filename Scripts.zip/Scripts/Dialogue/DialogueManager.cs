using UnityEngine;
using DG.Tweening;
using UnityEngine.UI;
public class DialogueManager : SingleTon<DialogueManager>
{
    [Header("Basic Elements")]
    public Image image;
    public Text mainText;
    public Button next;
    public GameObject dialogueCanvas;

    [Header("Options")]
    public RectTransform optionPanel;
    public OptionUI optionPre;
  
    [Header("Data")]
    public DialogueData_So dialogueData;
    int currentDataIndex = 0;
    protected override void Awake()
    {
        base.Awake();      
        next.onClick.AddListener(ContinueDialogue);
    }
    void ContinueDialogue()
    {
        if (currentDataIndex <  dialogueData.dialoguePieces.Count)
            UpdateText(dialogueData.dialoguePieces[currentDataIndex]);
        else
            dialogueCanvas.SetActive(false);
    }
    public void UpdateDialogueData(DialogueData_So data)
    {
        dialogueData = data;
        currentDataIndex = 0;
    }
    /// <summary>
    /// ���¶Ի������ʾ��Ǹ����ı�����
    /// </summary>
    /// <param name="piece"></param>
    public void UpdateText(DialoguePiece piece)
    {  
        dialogueCanvas.SetActive(true);
        currentDataIndex++;
        if (piece.image != null)
        {
            image.enabled = true;
            image.sprite = piece.image;
        }
        else
        {
            image.enabled = false;
        }
        mainText.text = "";
        mainText.text = piece.text;
        if(piece.dialogueOptions.Count == 0 && dialogueData.dialoguePieces.Count > 0)
        {
            //��ť���Ե������
            next.interactable = true;
            next.gameObject.SetActive(true);
            next.transform.GetChild(0).gameObject.SetActive(true);
        }
        else
        {
            next.interactable = false;
            next.transform.GetChild(0).gameObject.SetActive(false);
        }
        CreateOptions(piece);
    }
    /// <summary>
    /// ��ȡ��ǰPiece�����Ӧ��Option�ı�
    /// </summary>
    /// <param name="dialoguePiece"></param>
    void CreateOptions(DialoguePiece dialoguePiece)
    {
        if(optionPanel.childCount > 0)
        {
            for(int i = 0; i < optionPanel.childCount; i++)
            {
                Destroy(optionPanel.GetChild(i).gameObject);
            }
        }
        for(int i = 0; i < dialoguePiece.dialogueOptions.Count; i++)
        {
            var option = Instantiate(optionPre, optionPanel);
            option.UpdateOption(dialoguePiece,dialoguePiece.dialogueOptions[i]);
        }
    }   
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OptionUI : MonoBehaviour
{
    public Text optionText;
    public Button optionButton;
    public DialoguePiece currentPiece;
    private string nextPieceID;
    private bool takeQuest;
     void Awake()
    {
        optionButton = GetComponent<Button>();
        optionButton.onClick.AddListener(OnOptionClick);
    }
    /// <summary>
    /// ����Option�ı�
    /// </summary>
    /// <param name="piece"></param>
    /// <param name="option"></param>
    public void UpdateOption(DialoguePiece piece,DialogueOption option)
    {
        currentPiece = piece;
        optionText.text = option.text;
        nextPieceID = option.targetID;
        takeQuest = option.takeQuest;
    }
    public void OnOptionClick()
    {
        if(currentPiece.quest != null)
        {
            var newTask = new QuestManager.QuestTask();
            newTask.questData = Instantiate(currentPiece.quest);
            if (takeQuest)
            {
                if (QuestManager.Instance.HaveQuest(currentPiece.quest))
                {
                    if (QuestManager.Instance.GetQusetTask(newTask.questData).IsCompleted)
                    {
                        newTask.questData.GiveRewards();
                        QuestManager.Instance.GetQusetTask(newTask.questData).IsFinished = true;
                    }}
                else
                {
                    QuestManager.Instance.tasks.Add(newTask);
                    QuestManager.Instance.GetQusetTask(newTask.questData).IsStarted = true;
                    foreach(var requireItemName in newTask.questData.RequireTargetName())
                    {InventoryManager.Instance.CheckRequireItemInBag(requireItemName);}
                }
            }
        }
        if(nextPieceID == "")
        {DialogueManager.Instance.dialogueCanvas.SetActive(false);return;}
        else{DialogueManager.Instance.UpdateText(DialogueManager.Instance.dialogueData.dialogueIndex[nextPieceID]);
        }
    }
}

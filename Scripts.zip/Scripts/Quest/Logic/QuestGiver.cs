using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(DialogueController))]
public class QuestGiver : MonoBehaviour
{
    DialogueController dialogueController;
    QuestData_SO currentQuest;
    public DialogueData_So startDialogue;
    public DialogueData_So progressDialogue;
    public DialogueData_So completeDialogue;
    public DialogueData_So finishDialogue;
    #region �������״̬
    public bool IsStart
    {
        get 
        {
            if (QuestManager.Instance.HaveQuest(currentQuest))
            {
                return QuestManager.Instance.GetQusetTask(currentQuest).IsStarted;
            }
            else
            {
                return false;
            }
        }
    }
    public bool IsComplete
    {
        get
        {
            if (QuestManager.Instance.HaveQuest(currentQuest))
            {
                return QuestManager.Instance.GetQusetTask(currentQuest).IsCompleted;
            }
            else
            {
                return false;
            }
        }
    }
    public bool IsFinish
    {
        get
        {
            if (QuestManager.Instance.HaveQuest(currentQuest))
            {
                return QuestManager.Instance.GetQusetTask(currentQuest).IsFinished;
            }
            else
            {
                return false;
            }
        }
    }
    #endregion
    private void Awake()
    {
        dialogueController = GetComponent<DialogueController>();
    }
    private void Start()
    {
        dialogueController.currentData = startDialogue;
        currentQuest = dialogueController.currentData.GetQuest();
    }
    private void Update()
    {
        if (IsStart)
        {
            if (IsComplete)
            {dialogueController.currentData = completeDialogue;}
            else
            {
                dialogueController.currentData = progressDialogue;
            }
        }

        if (IsFinish)
        {
            dialogueController.currentData = finishDialogue;
        }
    }
}

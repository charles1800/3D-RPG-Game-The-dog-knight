using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

[CreateAssetMenu(fileName = "New Quest",menuName = "Quest/Quest Data")]
public class QuestData_SO : ScriptableObject
{
    [System.Serializable]
    public class QuestRequire
    {
        public string requireName;
        public int requireAmount;
        public int currentAmount;
    }
    public string questName;
    [TextArea]
    public string description;
    public bool isStarted;
    public bool isCompleted;
    public bool isFinshed;

    public List<QuestRequire> requireList = new List<QuestRequire>();
    public List<InventoryItem> rewards = new List<InventoryItem>();

    public void CheckQuestProgress() 
    {
        var finishRequires = requireList.Where(r => r.requireAmount <= r.currentAmount);
        isCompleted = finishRequires.Count() >= requireList.Count();
        if (isCompleted)
        {
            Debug.Log("Finish");
        }
    }
    public List<string> RequireTargetName()
    {
        List<string> targetName = new List<string>();
        foreach(var require in requireList)
        {
            targetName.Add(require.requireName);
        }
        return targetName;
    }
    public void GiveRewards()
    {
        foreach(var reward in rewards)
        {
            if(reward.itemAmount < 0)
            {
                int requireCount = Mathf.Abs(reward.itemAmount);
                if(InventoryManager.Instance.QuestItemInBag(reward.itemData) != null)
                {
                    if(InventoryManager.Instance.QuestItemInBag(reward.itemData).itemAmount <= requireCount)
                    {
                        requireCount -= InventoryManager.Instance.QuestItemInBag(reward.itemData).itemAmount;
                        InventoryManager.Instance.QuestItemInBag(reward.itemData).itemAmount = 0;

                        if(requireCount > 0 && InventoryManager.Instance.QuestItemInBag(reward.itemData) != null)
                        {
                            InventoryManager.Instance.QuestItemInAction(reward.itemData).itemAmount -= requireCount;
                        }
                    }else{InventoryManager.Instance.QuestItemInBag(reward.itemData).itemAmount -= requireCount;}
                }else{InventoryManager.Instance.QuestItemInAction(reward.itemData).itemAmount -= reward.itemAmount;}
            }
            else//Get reward
            {
                InventoryManager.Instance.inventoryData.AddItem(reward.itemData, reward.itemAmount);
            }
            InventoryManager.Instance.inventoryUI.RefreshUI();
            InventoryManager.Instance.actionUI.RefreshUI();
        }
    }
}

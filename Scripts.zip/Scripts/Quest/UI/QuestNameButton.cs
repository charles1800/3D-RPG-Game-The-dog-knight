using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestNameButton : MonoBehaviour
{
    public Text questNameText;
    public QuestData_SO currentData;
    public Text questDescription;
    private void Awake()
    {
        GetComponent<Button>().onClick.AddListener(UpdataQuestContent);
    }
    void UpdataQuestContent()
    {
        questDescription.text = currentData.description;
        QuestUI.Instance.UpdateRequireList(currentData);
        foreach(Transform item in QuestUI.Instance.rewardTransform)
        {
            Destroy(item.gameObject);
        }
        foreach(var item in currentData.rewards)
        {
            QuestUI.Instance.UpdateReward(item.itemData, item.itemAmount);
        }
    }
    public void SetUpButtonName(QuestData_SO questData)
    {
        currentData = questData;
        if (questData.isCompleted)
            questNameText.text = questData.name + " Finish ";
        else
            questNameText.text = questData.questName;
    }
}

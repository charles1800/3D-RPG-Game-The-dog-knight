using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestUI : SingleTon<QuestUI>
{
    [Header("Elements")]
    public GameObject questPanel;
    public ItemToolTip toolTip;
    bool isOpen;

    [Header("Quest Name")]
    public RectTransform questListTransform;
    public QuestNameButton questnameButton;

    [Header("Text Content")]
    public Text questContentText;

    [Header("Requirement")]
    public RectTransform requireTransform;
    public QuestRequirment requirment;

    [Header("Reward")]
    public RectTransform rewardTransform;
    public ItemUI reward;
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            isOpen = !isOpen;
            questPanel.SetActive(isOpen);
            questContentText.text = "";

            SetUpQuestList();
            if (!isOpen)
            {
                toolTip.gameObject.SetActive(false);
            }
        }
    }

    public void SetUpQuestList()
    {
        foreach(Transform item in questListTransform)
        {Destroy(item.gameObject);}
        foreach(Transform item in rewardTransform)
        {Destroy(item.gameObject);}
        foreach (Transform item in requireTransform)
        {Destroy(item.gameObject);}
        foreach(var task in QuestManager.Instance.tasks)
        {
            var newTask = Instantiate(questnameButton, questListTransform);
            newTask.SetUpButtonName(task.questData);
            newTask.questDescription = questContentText;
        }
    }
    public void UpdateRequireList(QuestData_SO questData)
    {
        foreach (Transform item in requireTransform)
        {
            Destroy(item.gameObject);
        }
        foreach (var require in questData.requireList)
        {
            var q = Instantiate(requirment, requireTransform);
            if (questData.isFinshed)
            {
                q.SetUpRequirment(questData.questName, questData.isFinshed);
            }
            else
            {
                q.SetUpRequirment(require.requireName, require.requireAmount, require.currentAmount);
            }        
        }
    }
    public void UpdateReward(ItemData_SO itemData,int amount)
    {
        if (amount > 0)
        {
            var item = Instantiate(reward, rewardTransform);
            item.SetupItemUI(itemData, amount);
        }
        
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestRequirment : MonoBehaviour
{
    private Text requireName;
    public Text progressNumber;

    private void Awake()
    {
        requireName = GetComponent<Text>(); 
        progressNumber = transform.GetChild(0).GetComponent<Text>();
    }
    /// <summary>
    /// ��������Ҫ��UI
    /// </summary>
    /// <param name="name"></param>
    /// <param name="amount"></param>
    /// <param name="currentAmount"></param>
    public void  SetUpRequirment(string name , int amount, int currentAmount)
    {
        Debug.Log("------------------------------");
        requireName.text = name;
        progressNumber.text = currentAmount + " / " + amount;
    }
    public void SetUpRequirment(string name, bool isFinished)
    {
        if (isFinished)
        {
            requireName.text = name;
            progressNumber.text = "���������";
            requireName.color = Color.gray;
            progressNumber.color = Color.gray;
        }
       
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
public class RewardToolTip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private ItemUI currentRewardUI;
    private void Awake()
    {
        currentRewardUI = GetComponent<ItemUI>();
    }
    public void OnPointerEnter(PointerEventData eventData)
    {
        QuestUI.Instance.toolTip.gameObject.SetActive(true);
        QuestUI.Instance.toolTip.SetUpInfo(currentRewardUI.rewardItemData);

    }

    public void OnPointerExit(PointerEventData eventData)
    {
        QuestUI.Instance.toolTip.gameObject.SetActive(false);

    }
}

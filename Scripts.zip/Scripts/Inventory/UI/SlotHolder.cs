using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
public enum SlotType 
{
BAG,
WEAPON,
EQUIPMENT,
ACTION
}
/// <summary>
/// ��Ӧÿһ�������е���Ʒ
/// </summary>
public class SlotHolder : MonoBehaviour, IPointerClickHandler,IPointerEnterHandler,IPointerExitHandler
{
    public SlotType slotType;
    public ItemUI itemUI;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.clickCount %2 == 0)
        {
            UseItem();
        }
    }
    public void UseItem()
    {
        if(itemUI.GetItemOfItemData() == null)
        {
            return;
        }
        if(itemUI.GetItemOfItemData().Type == ItemType.Useable 
            && itemUI.GetInventoryItem().itemAmount > 0)
        {
            GameManager.Instance.playerData.ApplyHealth(itemUI.GetItemOfItemData().useableItemData.healthPoint);
            itemUI.GetInventoryItem().itemAmount -= 1;
            QuestManager.Instance.UpdateProgress(itemUI.GetItemOfItemData().itemName, -1);
        }
        UpadateItem();
    }

    /// <summary>
    /// ����Ŀ����ӵ���Ʒ��Ӧ��Ϣ
    /// </summary>
    public void UpadateItem()
    {
        switch (slotType)
        {
            case SlotType.BAG:
                itemUI.Bag = InventoryManager.Instance.inventoryData;
                break;
            case SlotType.WEAPON:
                itemUI.Bag = InventoryManager.Instance.equipmentData;
                if (itemUI.Bag.items[itemUI.Index].itemData != null)
                {
                    GameManager.Instance.playerData.ChangeWeapon(itemUI.Bag.items[itemUI.Index].itemData);
                }
                else
                {
                    GameManager.Instance.playerData.UnEquipWeapon();
                }
                break;
            case SlotType.EQUIPMENT:
                itemUI.Bag = InventoryManager.Instance.equipmentData;
                break;
            case SlotType.ACTION:
                itemUI.Bag = InventoryManager.Instance.actionData;
                break;
            default:
                break;
        }
        var item = itemUI.Bag.items[itemUI.Index];
        itemUI.SetupItemUI(item.itemData, item.itemAmount);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if(itemUI.GetItemOfItemData())
        {
            InventoryManager.Instance.ToolInfo.gameObject.SetActive(true);
            InventoryManager.Instance.ToolInfo.SetUpInfo(itemUI.GetItemOfItemData());
        }
        
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        InventoryManager.Instance.ToolInfo.gameObject.SetActive(false);
    }
    private void OnDisable()
    {
        InventoryManager.Instance.ToolInfo.gameObject.SetActive(false);
    }
}

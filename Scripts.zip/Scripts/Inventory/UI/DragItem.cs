using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class DragItem : MonoBehaviour, IBeginDragHandler, IEndDragHandler, IDragHandler
{
    ItemUI currentItemUI;
    SlotHolder currentHolder;
    SlotHolder targetHolder;
    private void Awake()
    {
        currentItemUI = GetComponent<ItemUI>();
        currentHolder = GetComponentInParent<SlotHolder>();
    }
    public void OnBeginDrag(PointerEventData eventData)
    {
        InventoryManager.Instance.currentDrag = new InventoryManager.DragData();
        InventoryManager.Instance.currentDrag.originalHolder = GetComponent<SlotHolder>();
        InventoryManager.Instance.currentDrag.originalParent = (RectTransform)transform.parent;

        transform.SetParent(InventoryManager.Instance.dragCanvas.transform);
        //RectTransform currentRectTransform = currentHolder.GetComponentInParent<SlotHolder>().transform as RectTransform;
    }
    public void OnDrag(PointerEventData eventData)
    {
       transform.position = eventData.position;
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        if (EventSystem.current.IsPointerOverGameObject())
        {
            if (
                InventoryManager.Instance.CheckInventory(eventData.position) ||
                InventoryManager.Instance.CheckEquipmentUI(eventData.position) ||
                InventoryManager.Instance.CheckActionUI(eventData.position)
                )
            {
                if (eventData.pointerEnter.gameObject.GetComponent<SlotHolder>())
                    targetHolder = eventData.pointerEnter.gameObject.GetComponent<SlotHolder>();
                else
                    targetHolder = eventData.pointerEnter.gameObject.GetComponentInParent<SlotHolder>();    
                if (targetHolder != InventoryManager.Instance.currentDrag.originalHolder)
                {
                    switch (targetHolder.slotType)
                    {
                        case SlotType.BAG:
                            SwapItem();
                            break;
                        case SlotType.WEAPON:
                            if (currentItemUI.Bag.items[currentItemUI.Index].itemData.Type == ItemType.Weapon)
                                SwapItem();
                            break;
                        case SlotType.ACTION:
                            SwapItem();
                            break;
                    }
                }
                currentHolder.UpadateItem();
                targetHolder.UpadateItem();
            }
        }    
        transform.SetParent(InventoryManager.Instance.currentDrag.originalParent);
        RectTransform rectTransform = transform as RectTransform;
        rectTransform.offsetMax = -Vector2.one * 5;
        rectTransform.offsetMin = Vector2.one * 5;
    }
    public void SwapItem()
    {  
        var targetItem = targetHolder.itemUI.Bag.items[targetHolder.itemUI.Index];
        var tempItem = currentHolder.itemUI.Bag.items[currentHolder.itemUI.Index];
        //equals�Ƚϵ��������Ƿ���ͬ��==�Ƚϵ��ǵ�ַ�Ƿ���ͬ
        bool isSameItem = tempItem.itemData == targetItem.itemData;
        if(isSameItem && targetItem.itemData.stackAble)
        {
            targetItem.itemAmount += tempItem.itemAmount;
            
            tempItem.itemData = null;
            tempItem.itemAmount = 0;
        }
        else
        {
            currentHolder.itemUI.Bag.items[currentHolder.itemUI.Index] = targetItem;
            targetHolder.itemUI.Bag.items[targetHolder.itemUI.Index] = tempItem;
        }
    }

}

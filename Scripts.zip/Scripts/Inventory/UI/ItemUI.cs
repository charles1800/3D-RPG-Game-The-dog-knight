using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
/// <summary>
/// ������ʾ��ƷͼƬ�Լ�����
/// </summary>
public class ItemUI : MonoBehaviour
{
    public ItemData_SO rewardItemData;
    public Image icon = null;
    public Text amount = null;
    /// <summary>
    /// ���鱳��Data
    /// </summary>
    public InventoryData_SO Bag { get; set; }
    public int Index { get; set; } = -1;
    public void SetupItemUI(ItemData_SO item,int itemAmount)
    {
        if (itemAmount == 0)
        {
            GetInventoryItem().itemData = null;
            icon.gameObject.SetActive(false);
            return;
        }
        //���ڽ���UI��ʾ
        if (itemAmount < 0){item = null;}
        if (item != null)
        {
            rewardItemData = item;
            icon.sprite = item.itemIcon;
            amount.text = itemAmount.ToString();
            icon.gameObject.SetActive(true);
        }
        else
        {
            icon.gameObject.SetActive(false);
        }
    }
    /// <summary>
    /// ��ȡ�������Item����
    /// </summary>
    /// <returns></returns>
    public ItemData_SO GetItemOfItemData()
    {
        return Bag.items[Index].itemData;
    }
    /// <summary>
    /// ��ȡĿ��Item��Inventory������ġ�
    /// </summary>
    /// <returns></returns>
    public InventoryItem GetInventoryItem()
    {
        return Bag.items[Index];
    }
}

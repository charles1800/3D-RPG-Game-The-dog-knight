using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public enum ItemType {Useable,Weapon}
[CreateAssetMenu(fileName = "New Item", menuName = "Inventory/Item Data")]
public class ItemData_SO : ScriptableObject
{
    public ItemType Type;
    public string itemName;
    public Sprite itemIcon;
    public int itemAmount;
    [TextArea]
    public string itemDescription = "";
    public bool stackAble;
    [Header("Useable Item")]
    public UsableItem_SO useableItemData;
    [Header("Weapon")]
    public GameObject weaponPrefab;
    public AttackData_SO weaponData;
    public AnimatorOverrideController weaponAnimator;
}
   

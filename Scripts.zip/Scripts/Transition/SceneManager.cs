using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class SceneManager : SingleTon<SceneManager>,IEndGameObserver
{
    private GameObject player;
    public GameObject playerPrefab;
     NavMeshAgent agent;
    public SceneFade sceneFade;
    bool fadeFinished;
    protected override void Awake()
    {
        base.Awake();
        DontDestroyOnLoad(this);
    }
    private void Start()
    {
        GameManager.Instance.AddObserver(this);
        fadeFinished = true;
    }
    public void TransitionToDestination(TransitionPoint transitionPoint)
    {
        switch (transitionPoint.transitionType)
        {
            case TransitionPoint.TransitionType.SameScene:
                StartCoroutine(Transition(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name, transitionPoint.destinationTag));
                break;
            case TransitionPoint.TransitionType.DifferentScene:
                StartCoroutine(Transition(transitionPoint.sceneName,transitionPoint.destinationTag));
                break;
        }       
    }
    public void TransitionToLoadGame()
    {
        StartCoroutine(LoadLevel(SaveManager.Instance.SceneName));
    }
    public void TransitionToLoadMain()
    {
        StartCoroutine(LoadMain());
    }
    IEnumerator Transition(string sceneName,TransitionDestination.DestinationTag destinationTag)
    {
        InventoryManager.Instance.SaveData();
        SaveManager.Instance.SavePlayerData();
        if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().name == sceneName)
        {
            player = GameManager.Instance.playerData.gameObject;
            agent = player.GetComponent<NavMeshAgent>();
            agent.isStopped = true;
            player.transform.SetPositionAndRotation(this.GetDestination(destinationTag).transform.position, this.GetDestination(destinationTag).transform.rotation);
            yield return null;
        }
        else
        {
            yield return UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(sceneName);
            yield return Instantiate(
                playerPrefab,
                this.GetDestination(destinationTag).transform.position,
                this.GetDestination(destinationTag).transform.rotation
                );
            //��ȡ����
            SaveManager.Instance.LoadPlayerData();
            yield break;
                   
        }
    }
    private TransitionDestination GetDestination(TransitionDestination.DestinationTag destinationTag)
    {
        var entrances = FindObjectsOfType<TransitionDestination>();
        foreach(var entrance in entrances)
        {
            if(entrance.destinationTag == destinationTag)
            {
                return entrance;
            }
        }
        return null;
    }
    public void TransitionToFirstLevel()
    {
        StartCoroutine(LoadLevel("SampleScene"));
    }

    IEnumerator LoadLevel(string sceneName)
    {
        SceneFade fade = Instantiate(sceneFade);       
        if (sceneName != "")
        {
            yield return StartCoroutine(fade.FadeOut(2.5f));
            yield return UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(sceneName);
            yield return player = Instantiate(playerPrefab, GameManager.Instance.GetEntrance().position, GameManager.Instance.GetEntrance().rotation);
            SaveManager.Instance.SavePlayerData();
            InventoryManager.Instance.SaveData();
            yield return StartCoroutine(fade.FadeIn(2.5f));
            yield  break;
        }      
    }

    IEnumerator LoadMain()
    {
        yield return UnityEngine.SceneManagement.SceneManager.LoadSceneAsync("Main");
        yield break;
    }
    public void EndNotify()
    {
        if (fadeFinished)
        {
            fadeFinished = false;
            StartCoroutine(LoadMain());
        }
    }
}

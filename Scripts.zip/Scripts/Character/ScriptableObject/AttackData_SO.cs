using UnityEngine;
[CreateAssetMenu(fileName = "New Attack",menuName = "Attack/Attack Data")]
public class AttackData_SO : ScriptableObject
{
    public float attackRange;
    public float skillRange;
    [Tooltip("attack CD and damage")]
    public float coolDown;
    public int minDamage;
    public int maxDamage;
    [Tooltip("critical damage")]
    public float criticalMultiplier;
    public float criticalChance;
    /// <summary>
    /// While change weapon,change the data of its attack data.
    /// </summary>
    /// <param name="weapon"></param>
    public void ApplyWeaponData(AttackData_SO weapon)
    {
        attackRange = weapon.attackRange;
        skillRange = weapon.skillRange;
        coolDown = weapon.coolDown;
        minDamage = weapon.minDamage;
        maxDamage = weapon.maxDamage;
        criticalMultiplier = weapon.criticalMultiplier;
        criticalChance = weapon.criticalChance;
    }
}

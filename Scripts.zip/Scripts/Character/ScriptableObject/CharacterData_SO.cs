using UnityEngine;
[CreateAssetMenu(fileName = "New Data",menuName = "Character Stats/Character Data")]
public class CharacterData_SO : ScriptableObject
{
    [Header("Player Info")]
    public int maxHealth;
    public int currentHealth;
    public int baseDefence;
    public int currentDefence;
    [Header("Kill Experience")]
    public int killPoint;
    [Header("Level")]
    public int currentLevel;
    public int maxLevel;
    public int baseExp;
    public int currentExp;
    public float levelBuff;

    public float LevelMultiplier
    {
        get
        {
            return 1 + (currentLevel - 1) * levelBuff;
        }
    }
    public void UpdateExp(int point)
    {
        currentExp += point;
        if (currentExp >= baseExp)
        {
            LevelUp();
        }
    }
    private void LevelUp()
    {
        //Limit the max level
        currentLevel = Mathf.Clamp(currentLevel + 1, 0, maxLevel);
        baseExp += (int)(baseExp * LevelMultiplier);

        maxHealth += 10;
        currentHealth = maxHealth;
        Debug.Log("Level Up!");
    }
}

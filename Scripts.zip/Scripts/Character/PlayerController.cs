using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class PlayerController : MonoBehaviour
{
    private NavMeshAgent agent;

    private Collider collider;
    
    bool isDead;
    
    private GameObject attackTarget;
    
    private float attackTime;

    private Animator animator;
    [Tooltip("��ɫ����")]
    private CharacterData player;

    private float stopDistance;

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
        player = GetComponent<CharacterData>();
        collider = GetComponent<Collider>();
        stopDistance = agent.stoppingDistance;
        
    }
    private void OnEnable()
    {
        MouseManager.Instance.OnMouseClicked += MoveToTarget;
        MouseManager.Instance.OnStuffClicked += AttackEvent;
        GameManager.Instance.RegisterPlayer(player);
    }
    private void Start()
    {
        SaveManager.Instance.LoadPlayerData();
    }
   
    private void OnDisable()
    {
        if (!MouseManager.IsInitialized) return;
        MouseManager.Instance.OnMouseClicked -= MoveToTarget;
        MouseManager.Instance.OnStuffClicked -= AttackEvent;
    }


    private void Update()
    {
        SwitchAnimation();
        attackTime -= Time.deltaTime;
        if (player.CurrentHealthy <= 0) 
        {
            isDead = true;
            agent.enabled = false;
            collider.enabled = false;
            GameManager.Instance.NotifyObserver();
        }
       
    }

    private void SwitchAnimation()
    {
        animator.SetFloat("Speed",agent.velocity.sqrMagnitude);

        animator.SetBool("Death", isDead);
    }
    public void MoveToTarget(Vector3 target)
    {
        StopAllCoroutines();
        if (isDead){return;}
        agent.isStopped = false;
        agent.stoppingDistance = stopDistance;
        agent.destination = target;
    }

    public void AttackEvent(GameObject gameObject)
    {
        if (isDead)
        {
            return;
        }
        if (gameObject == null)
        {
            return;
        }
        Debug.Log("111111111111");
        attackTarget = gameObject;
        player.isCritical = Random.value < player.attackData.criticalChance;
        StartCoroutine(MoveToAttackTarget());     
    }
    IEnumerator MoveToAttackTarget()
    {       
        agent.isStopped = false;
        agent.stoppingDistance = player.attackData.attackRange;
        while(Vector3.Distance(
            attackTarget.transform.position,transform.position)
            > player.attackData.attackRange)
        {
            
            agent.destination = attackTarget.transform.position;     
            
            yield return null;
        }
        agent.isStopped = true;
        if(attackTime < 0)
        {
            Debug.Log("11111111111122222");
            animator.SetBool("CriticalAttack",player.isCritical);
            animator.SetTrigger("Attack");
           transform.LookAt(attackTarget.transform.position);
            attackTime = 1;
        }
      
    }
    

    //�����¼�
    void Hit()
    {
        //����ʯͷ������
        if (attackTarget.CompareTag("Attackable"))
        {
            if(attackTarget.GetComponent<ThrowRock>() )
            {
                attackTarget.GetComponent<ThrowRock>().state = ThrowRock.RockStates.HitEnemy;
                attackTarget.GetComponent<Rigidbody>().velocity = Vector3.one;
                attackTarget.GetComponent<Rigidbody>().AddForce(transform.forward * 20 , ForceMode.Impulse);
            }
        }else
        {
            var targetStats = attackTarget.GetComponent<CharacterData>();
            targetStats.TakeDamage(player, targetStats);
        }

    }
}

using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;

public class CharacterData : MonoBehaviour
{
    public event Action<int, int> UpdateHealthBarWhenAttack;

    public CharacterData_SO characterData;
    public CharacterData_SO templateData;

    public AttackData_SO attackData;
    public AttackData_SO baseAttackData;

    /// <summary>
    /// ��ɫԭʼ����
    /// </summary>
    private RuntimeAnimatorController baseAnimator;
    [Header("Weapon")]
    public Transform weaponSlot;

    [HideInInspector]
    public bool isCritical;
    #region ��ɫ����
    public int MaxHealth
    {
        get
        {
            if (characterData != null)
            {
                return characterData.maxHealth;
            }
            else
            {
                return 0;
            }
        }
        set
        {
            //value��ʾ����������Եĸ�ֵ
            characterData.maxHealth = value;
        }
    }
    public int CurrentHealthy
    {
        get
        {
            if (characterData != null){ return characterData.currentHealth;}
            else{return 0;}
        }
        set
        {
            characterData.currentHealth = value;
        }
    }
    public int BaseDefence
    {
        get
        {
            if (characterData != null)
            {
                return characterData.baseDefence;
            }
            else
            {
                return 0;
            }
        }
        set
        {
            //value��ʾ����������Եĸ�ֵ
            characterData.baseDefence = value;
        }
    }
    public int CurrentDefence
    {
        get
        {
            if (characterData != null)
            {
                return characterData.currentDefence;
            }
            else
            {
                return 0;
            }
        }
        set
        {
            //value��ʾ����������Եĸ�ֵ
            characterData.currentDefence = value;
        }
    }
    #endregion
    /// <summary>
    /// ������Ƶ��˺����ݹ��õ����⣬����һ������
    /// </summary>
    private void Awake()
    {
        if (templateData != null)
        {
            characterData = Instantiate(templateData);
        }
        baseAttackData = Instantiate(attackData);
        baseAnimator = GetComponent<Animator>().runtimeAnimatorController;
    }
    #region Character Combat
    /// <summary>
    /// ��ȡ�˺�ֵ������defender��Ѫ���Լ������������Ķ���������Ѫ��UI��
    /// </summary>
    /// <param name="attcker"></param>
    /// <param name="defender"></param>
    public void TakeDamage(CharacterData attcker, CharacterData defender)
    {
        int damage =Mathf.Max
            ( 
            attcker.CurrentDamage() - defender.CurrentDefence,1
            );
        defender.CurrentHealthy = Mathf.Max(CurrentHealthy - damage, 0);
        if (attcker.isCritical)
        {
            defender.GetComponent<Animator>().SetTrigger("Hit");
        }
        UpdateHealthBarWhenAttack?.Invoke(CurrentHealthy, MaxHealth);
        if (CurrentHealthy <= 0)
        {
            GameManager.Instance.playerData.characterData.UpdateExp(characterData.killPoint);
        }
        Debug.Log(damage + attcker.name);
    }
    public void TakeDamage(int damage1, CharacterData defender)
    {
        int damage = Mathf.Max(damage1 - defender.CurrentDefence, 0);
        Debug.Log("damage " + gameObject.tag  + damage);
        defender.CurrentHealthy = Mathf.Max(CurrentHealthy - damage, 0);
        UpdateHealthBarWhenAttack?.Invoke(CurrentHealthy, MaxHealth);      
    }
    /// <summary>
    /// Calculate the damage
    /// </summary>
    /// <returns></returns>
    private int CurrentDamage()
    {
        float coreDamage = UnityEngine.Random.Range(attackData.minDamage, attackData.maxDamage);
        if (isCritical)
        {
            return (int)(coreDamage * attackData.criticalMultiplier);        
        }
        return (int)(coreDamage);    
    }
    #endregion

    #region Equip Weapon
    /// <summary>
    /// װ������
    /// </summary>
    /// <param name="weapon"></param>
    public void EquipWeapon(ItemData_SO weapon)
    {
        if(weapon.weaponPrefab != null)
        {
            Instantiate(weapon.weaponPrefab, weaponSlot);
            //TODO����������
            //TODO:�л�����
            attackData.ApplyWeaponData(weapon.weaponData);
            //ʵʱ��������
            GetComponent<Animator>().runtimeAnimatorController = weapon.weaponAnimator;
        }
  
    }
    public void ChangeWeapon(ItemData_SO weapon)
    {
        UnEquipWeapon();
        EquipWeapon(weapon);
    }
    public void UnEquipWeapon()
    {
        if(weaponSlot.transform.childCount != 0)
        {
            for(int i =0; i < weaponSlot.transform.childCount; i++)
            {
                Destroy(weaponSlot.transform.GetChild(i).gameObject);
            }
        }
        attackData.ApplyWeaponData(baseAttackData);
        //TODO:�л�����
        GetComponent<Animator>().runtimeAnimatorController = baseAnimator;
                    
    }
    /*public void ApplyWeaponData(AttackData_SO weapon)
    {
        attackData.attackRange = weapon.attackRange;
        attackData.skillRange = weapon.skillRange;
        attackData.coolDown = weapon.coolDown;
        attackData.minDamage = weapon.minDamage;
        attackData.maxDamage = weapon.maxDamage;
        attackData.criticalMultiplier = weapon.criticalMultiplier;
        attackData.criticalChance = weapon.criticalChance;
    }*/
    #endregion

    #region Apply Data Change
    public void ApplyHealth(int amount)
    {
        if(CurrentHealthy + amount < MaxHealth)
        {
            CurrentHealthy += amount;
        }
        else
        {
            Debug.Log("Ѫ����");
            CurrentHealthy = MaxHealth;
        }
    }
    #endregion
}
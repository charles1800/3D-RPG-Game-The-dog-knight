using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(MeshCollider))]
public class ThrowRock : MonoBehaviour
{
    public enum RockStates
    {
        HitPlayer, HitEnemy, HitNothing
    }

    public RockStates state;
    private Rigidbody rb;
    public GameObject breakEffect;
    public float force = 100f;
    public GameObject target;
    public int damage;
    /// <summary>
    /// ��ȡ����
    /// </summary>
    Vector3 direction;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        state = RockStates.HitPlayer;
        rb.velocity = Vector3.one;
        FlyToTarget();
    }
    private void FixedUpdate()
    {
         if(rb.velocity.sqrMagnitude < 1)
        {
            state = RockStates.HitNothing;
        }
    }
    public void FlyToTarget()
    {
        if(target == null)
        {
            target = FindObjectOfType<PlayerController>().gameObject;
        }    
        direction = target.transform.position - transform.position +  Vector3.up ;
        direction.Normalize();        
        rb.AddForce(direction * force, ForceMode.Impulse);
    }
    void OnCollisionEnter(Collision collision)
    {
        switch (state)
        {
            case RockStates.HitEnemy:
                if (collision.gameObject.GetComponent<StoneGiant>())
                {
                    var otherStats = collision.gameObject.GetComponent<CharacterData>();
                    otherStats.TakeDamage(damage, otherStats);
                    Instantiate(breakEffect, transform.position, Quaternion.identity);
                    Destroy(gameObject);    
                }             
                    break;
            case RockStates.HitNothing:
                break;
            case RockStates.HitPlayer:
                if (collision.gameObject.CompareTag("Player"))
                {
                    collision.gameObject.GetComponent<NavMeshAgent>().isStopped = true;
                    collision.gameObject.GetComponent<NavMeshAgent>().velocity = direction * force;

                    collision.gameObject.GetComponent<Animator>().SetTrigger("Dizzy");
                    collision.gameObject.GetComponent<CharacterData>().TakeDamage(damage, collision.gameObject.GetComponent<CharacterData>());
                    state = RockStates.HitNothing;
                }
                break;
        }
    }
}


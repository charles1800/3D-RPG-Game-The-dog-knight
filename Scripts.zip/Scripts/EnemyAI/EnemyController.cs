using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


public enum EnemyStates
{
    PATROL,CHASE,DEAD
}
//���Զ�����Component
[RequireComponent(typeof(NavMeshAgent))]
[RequireComponent(typeof(CharacterData))]
[RequireComponent(typeof(BoxCollider))]
public class EnemyController : MonoBehaviour,IEndGameObserver
{
    public EnemyStates enemyStates;
    private NavMeshAgent agent;
    private Animator animator;
    protected GameObject attackTarget;
    protected CharacterData characterData;
    private float lastAttackTime;
    private Collider collider1;
    [Tooltip("��֪��Χ�뾶")]
    public float signRadius = 5.0f;
    public float enemySpeed = 2.5f;

    bool isWalk;
    bool isChase;
    bool isFollow;
    bool isDead;

    [Header("Patrol State")]
    public float patrolRange;
    private Vector3 PatrolPoint;
   
    [Tooltip("��ȡ��ʼ���꣬ʹ����һ���̶���λ��")]
    private Vector3 GuardPoint;
    
    [Tooltip("ʹAI����Destination��ͣ��3s���ƶ�")]
    public float LookAtTime = 3f;

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();

        animator = GetComponent<Animator>();

        GuardPoint = transform.position;

        collider1 = GetComponent<Collider>();

        characterData = GetComponent<CharacterData>();
    }
    private void Start()
    {
        GetPartolPoints(); 
    }

     void OnEnable()
    {
        GameManager.Instance.AddObserver(this);
    }
    void OnDisable()
    {
        if (!GameManager.IsInitialized) return;
        GameManager.Instance.RemoveObserver(this);

        if (GetComponent<LootSpawner>() && isDead)
        {
            GetComponent<LootSpawner>().SpawnLoot();
        }

        if(QuestManager.IsInitialized && isDead)
        {
            QuestManager.Instance.UpdateProgress(this.name, 1);
        }
    }

    private void Update()
    {
        SwitchStates();
        NormalAnimation();
        lastAttackTime -= Time.deltaTime; 

        if(characterData.CurrentHealthy <= 0)
        {
            isDead = true;
        }
    }

    void NormalAnimation()
    {
        animator.SetBool("Walk", isWalk);
        animator.SetBool("Chase", isChase);
        animator.SetBool("Follow", isFollow);
        animator.SetBool("CriticalAttack", characterData.isCritical);
        animator.SetBool("Death",isDead);
    }

    void SwitchStates()
    {
        if (isDead)
        {
            enemyStates = EnemyStates.DEAD;
        }
        else if (FindPlayer())
        {
            enemyStates = EnemyStates.CHASE;
        }
        else
        {
            isFollow = false;
            enemyStates = EnemyStates.PATROL;
        }
        switch (enemyStates)
        {
            case EnemyStates.PATROL:
                agent.speed = enemySpeed ;
                isChase = false;
                agent.speed = 1f;
                if(Vector3.Distance(PatrolPoint,transform.position)<= agent.stoppingDistance)
                {
                    isWalk = false;
                    if (LookAtTime > 0)
                    {
                        LookAtTime -= Time.deltaTime;

                        Debug.Log("22222222");
                    }
                    else
                    {
                        Debug.Log("221111111112 " + gameObject.name);
                        GetPartolPoints();
                        LookAtTime = 3f;
                    }
                }
                else
                {
                    Debug.Log("222224444444444");
                    isWalk = true;
                    agent.destination = PatrolPoint;
                }
                break;
            case EnemyStates.CHASE:
                isWalk = false;
                isChase = true;
                if (!FindPlayer())
                {
                    isFollow = false;
                    agent.destination = transform.position;
                }
                else
                {
                    agent.isStopped = false;
                    isFollow = true;
                    agent.speed = enemySpeed * 2;
                    agent.destination = attackTarget.transform.position;
                }
                if (TargetInAttackRange() || TargetInSkillRange())
                {
                    isChase = false;
                    isFollow = false;
                    agent.isStopped = true;
                    if(lastAttackTime < 0)
                    {
                        lastAttackTime = characterData.attackData.coolDown;
                        characterData.isCritical = Random.value < characterData.attackData.criticalChance;
                        Attack();
                    }
                }
                break;

            case EnemyStates.DEAD:
                collider1.enabled = false;
                agent.enabled = false;              
                Destroy(gameObject,2f);
                break;
        }
    }

    void Attack()
    {
        transform.LookAt(attackTarget.transform);

        if (TargetInAttackRange())
        {
            animator.SetTrigger("BaseAttack"); 
        }
        if (TargetInSkillRange())
        {
            animator.SetTrigger("BaseAttack");
        }
    }
    
    bool TargetInAttackRange()
    {
        if(attackTarget != null)
        {
            return Vector3.Distance(attackTarget.transform.position, transform.position) <= characterData.attackData.attackRange;
        }
        else{
            return false;
        }
    }
    bool TargetInSkillRange()
    {
        if (attackTarget != null)
        {
            return Vector3.Distance(attackTarget.transform.position, transform.position) <= characterData.attackData.skillRange;
        }
        else
        {
            return false;
        }
    }

    bool FindPlayer()
    {
        var colliders = Physics.OverlapSphere(transform.position, signRadius);
        foreach (var collider in colliders)
        {
            if (collider.CompareTag("Player"))
            {
                attackTarget = collider.gameObject;
                return true;
            }
        }
        attackTarget = null;
        return false;
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, patrolRange);
    }
    /// <summary>
    /// ��ȡ���Ѳ�ߵĵ�
    /// </summary>
    void GetPartolPoints()
    {
        float randomX = Random.Range(-patrolRange, patrolRange);
        float randomZ = Random.Range(-patrolRange, patrolRange);
        Vector3 randomPoint = new Vector3(GuardPoint.x + randomX, GuardPoint.y, GuardPoint.z + randomZ) ;
        //����������ϰ����޷��ƶ������,���randomPoint��walkable�ͷ���true
        NavMeshHit hit;
        PatrolPoint = NavMesh.SamplePosition(randomPoint, out hit,patrolRange,1)? hit.position:transform.position;
    }
    void Hit()
    {
        if(attackTarget != null && transform.isFaceingTarget(attackTarget.transform))
        {
            var targetStats = attackTarget.GetComponent<CharacterData>();
            targetStats.TakeDamage(characterData, targetStats);
        }
    }

    public void EndNotify()
    {
        isChase = false;
        isWalk = false;
        attackTarget = null;
        //TODO: Play Animation
    }
}


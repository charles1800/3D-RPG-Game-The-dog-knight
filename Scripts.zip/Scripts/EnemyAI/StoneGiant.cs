using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class StoneGiant : EnemyController
{
    [Header("Skill")]
    public float kickForce = 15;
    public GameObject rockPrefab;
    public Transform handPos;

   public void KickOff()
    {
        if (attackTarget != null && transform.isFaceingTarget(attackTarget.transform))
        {
            var targetStats = attackTarget.GetComponent<CharacterData>();
            Vector3 direction = attackTarget.transform.position - transform.position;
            direction.Normalize();
            attackTarget.GetComponent<NavMeshAgent>().isStopped = true;
            attackTarget.GetComponent<NavMeshAgent>().velocity = direction * kickForce;
            print("=======" + attackTarget.GetComponent<NavMeshAgent>().velocity);
           // attackTarget.GetComponent<Animator>().SetTrigger("Dizzy");
            targetStats.TakeDamage(characterData, targetStats);
        }
    }
    public void ThrowRock()
    {
        Debug.Log("����ʯͷ");
        if(attackTarget != null)
        {
            var rock = Instantiate(rockPrefab,handPos.position,Quaternion.identity);
            rock.GetComponent<ThrowRock>().target = attackTarget;
        }
    }
}
